package com.horrormod;

import com.horrormod.config.HorrorConfig;
import com.horrormod.entity.ModEntities;
import com.horrormod.event.HorrorEventHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(modid = HorrorMod.MODID, name = HorrorMod.NAME, version = HorrorMod.VERSION,
     acceptedMinecraftVersions = "[1.12,1.13)")
public class HorrorMod {

    public static final String MODID   = "horrormod";
    public static final String NAME    = "Reality Fracture";
    public static final String VERSION = "1.0.0";

    public static final Logger LOG = LogManager.getLogger(NAME);

    @SidedProxy(
        clientSide = "com.horrormod.client.ClientProxy",
        serverSide = "com.horrormod.CommonProxy"
    )
    public static CommonProxy proxy;

    @Mod.Instance(MODID)
    public static HorrorMod instance;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        HorrorConfig.init(event.getSuggestedConfigurationFile());
        ModEntities.registerEntities();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new HorrorEventHandler());
        proxy.registerRenderers();
        LOG.info("[HorrorMod] Initialized. They are already watching.");
    }
}
