package com.horrormod.entity;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class EntityTheFracture extends EntityCreature {

    private int soundTimer     = 0;
    private int blockBreakTimer = 0;

    public EntityTheFracture(World world) {
        super(world);
        this.isImmuneToFire = true;
        this.setSize(1.0f, 2.5f);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(200.0);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.28);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0);
        this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0);
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIMoveTowardsTarget(this, 0.9, 32));
        this.tasks.addTask(3, new EntityAIWander(this, 0.6));
        this.tasks.addTask(4, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAINearestAttackableTarget<>(this, EntityPlayer.class, true));
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) return;

        soundTimer++;
        blockBreakTimer++;

        if (soundTimer >= 40 + world.rand.nextInt(60)) {
            soundTimer = 0;
            playFractureSound();
        }

        if (blockBreakTimer >= 20) {
            blockBreakTimer = 0;
            tryBreakBlocksTowardPlayer();
        }

        // Glitch teleport 3% chance per tick
        if (world.rand.nextInt(100) < 3) {
            spawnFractureParticles();
            double tx = posX + (world.rand.nextDouble() - 0.5) * 8;
            double tz = posZ + (world.rand.nextDouble() - 0.5) * 8;
            setPosition(tx, posY, tz);
            spawnFractureParticles();
        }
    }

    private void playFractureSound() {
        String[] sounds = {
            "entity.blaze.ambient",
            "ambient.cave",
            "entity.endermen.scream",
            "entity.ghast.scream"
        };
        String sound = sounds[world.rand.nextInt(sounds.length)];
        SoundEvent se = SoundEvent.REGISTRY.getObject(new ResourceLocation(sound));
        if (se != null)
            world.playSound(null, posX, posY, posZ, se, SoundCategory.HOSTILE,
                1.5f, 0.3f + world.rand.nextFloat() * 0.4f);
    }

    private void tryBreakBlocksTowardPlayer() {
        EntityPlayer player = world.getClosestPlayerToEntity(this, 32);
        if (player == null) return;

        double dx = player.posX - posX;
        double dz = player.posZ - posZ;
        double len = Math.sqrt(dx*dx + dz*dz);
        if (len < 2) return;
        dx /= len; dz /= len;

        for (int step = 1; step <= 4; step++) {
            int bx = (int)(posX + dx * step);
            int by = (int)(posY + 0.5);
            int bz = (int)(posZ + dz * step);

            BlockPos pos     = new BlockPos(bx, by, bz);
            BlockPos posAbove = pos.up();

            IBlockState state = world.getBlockState(pos);
            if (state.getBlock() != Blocks.AIR && state.getBlock() != Blocks.BEDROCK) {
                world.setBlockToAir(pos);
            }
            IBlockState stateAbove = world.getBlockState(posAbove);
            if (stateAbove.getBlock() != Blocks.AIR && stateAbove.getBlock() != Blocks.BEDROCK) {
                world.setBlockToAir(posAbove);
            }
        }
    }

    private void spawnFractureParticles() {
        for (int i = 0; i < 20; i++) {
            world.spawnParticle(EnumParticleTypes.PORTAL,
                posX + (world.rand.nextDouble() - 0.5) * 2,
                posY + world.rand.nextDouble() * 2.5,
                posZ + (world.rand.nextDouble() - 0.5) * 2,
                0, 0.1, 0
            );
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        SoundEvent se = SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.endermen.hit"));
        if (se != null)
            world.playSound(null, posX, posY, posZ, se, SoundCategory.HOSTILE, 1.0f, 0.5f);
        return super.attackEntityFrom(source, amount);
    }

    @Override
    protected void onDeathUpdate() {
        super.onDeathUpdate();
        if (deathTime == 1) {
            spawnFractureParticles();
            SoundEvent se = SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.endermen.teleport"));
            if (se != null)
                world.playSound(null, posX, posY, posZ, se, SoundCategory.HOSTILE, 2.0f, 0.5f);
        }
    }

    @Override
    protected boolean canDespawn() { return false; }
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.endermen.ambient"));
    }
    @Override
    protected SoundEvent getHurtSound(DamageSource src) {
        return SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.endermen.hurt"));
    }
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.endermen.death"));
    }
    @Override
    protected int getExperiencePoints(EntityPlayer player) { return 100; }
}
