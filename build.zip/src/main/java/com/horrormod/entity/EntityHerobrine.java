package com.horrormod.entity;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;

public class EntityHerobrine extends EntityCreature {

    private int ticksAlive = 0;
    private int lifespanTicks;
    private boolean vanished = false;
    private EntityPlayer targetPlayer;

    public EntityHerobrine(World world) {
        super(world);
        this.isImmuneToFire = true;
        this.noClip = true;
        this.lifespanTicks = 300 + world.rand.nextInt(300);
        this.setSize(0.6f, 1.8f);
    }

    public void setTargetPlayer(EntityPlayer player) {
        this.targetPlayer = player;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(1.0);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.0);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) return;

        ticksAlive++;

        if (targetPlayer == null || targetPlayer.isDead) {
            setDead();
            return;
        }

        double dx = targetPlayer.posX - posX;
        double dz = targetPlayer.posZ - posZ;
        rotationYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));

        if (isPlayerLookingAt(targetPlayer) || ticksAlive >= lifespanTicks) {
            vanishWithPortalEffects();
        }
    }

    private boolean isPlayerLookingAt(EntityPlayer player) {
        float yaw   = player.rotationYaw;
        float pitch = player.rotationPitch;
        double lookX = -Math.sin(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch));
        double lookY = -Math.sin(Math.toRadians(pitch));
        double lookZ =  Math.cos(Math.toRadians(yaw))  * Math.cos(Math.toRadians(pitch));

        double toX = posX - player.posX;
        double toY = (posY + height / 2) - (player.posY + player.getEyeHeight());
        double toZ = posZ - player.posZ;
        double len = Math.sqrt(toX*toX + toY*toY + toZ*toZ);
        if (len < 0.001) return true;
        toX /= len; toY /= len; toZ /= len;

        return (lookX*toX + lookY*toY + lookZ*toZ) > 0.94;
    }

    private void vanishWithPortalEffects() {
        if (vanished) return;
        vanished = true;
        for (int i = 0; i < 30; i++) {
            world.spawnParticle(EnumParticleTypes.PORTAL,
                posX + (world.rand.nextDouble() - 0.5) * 2,
                posY + world.rand.nextDouble() * 2,
                posZ + (world.rand.nextDouble() - 0.5) * 2,
                (world.rand.nextDouble() - 0.5) * 0.5,
                world.rand.nextDouble() * 0.5,
                (world.rand.nextDouble() - 0.5) * 0.5
            );
        }
        world.playSound(null, posX, posY, posZ,
            SoundEvent.REGISTRY.getObject(new ResourceLocation("ambient.cave")),
            SoundCategory.HOSTILE, 1.0f, 0.5f + world.rand.nextFloat() * 0.5f);
        setDead();
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) { return false; }
    @Override
    protected boolean canDespawn() { return false; }
    @Override
    public boolean canBePushed() { return false; }
    @Override
    protected SoundEvent getAmbientSound() { return null; }
    @Override
    protected SoundEvent getHurtSound(DamageSource src) { return null; }
    @Override
    protected SoundEvent getDeathSound() { return null; }
    @Override
    public boolean getAlwaysRenderNameTag() { return false; }
}
