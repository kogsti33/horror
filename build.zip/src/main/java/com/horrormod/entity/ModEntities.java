package com.horrormod.entity;

import com.horrormod.HorrorMod;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

public class ModEntities {

    public static void registerEntities() {
        int id = 64;

        EntityRegistry.registerModEntity(
            new ResourceLocation(HorrorMod.MODID, "the_watcher"),
            EntityTheWatcher.class, "the_watcher", id++,
            HorrorMod.instance, 80, 3, true
        );
        EntityRegistry.registerModEntity(
            new ResourceLocation(HorrorMod.MODID, "herobrine"),
            EntityHerobrine.class, "herobrine", id++,
            HorrorMod.instance, 80, 3, true
        );
        EntityRegistry.registerModEntity(
            new ResourceLocation(HorrorMod.MODID, "illusion_player"),
            EntityIllusionPlayer.class, "illusion_player", id++,
            HorrorMod.instance, 80, 3, true
        );
        EntityRegistry.registerModEntity(
            new ResourceLocation(HorrorMod.MODID, "the_fracture"),
            EntityTheFracture.class, "the_fracture", id++,
            HorrorMod.instance, 160, 3, true
        );

        HorrorMod.LOG.info("[HorrorMod] Entities registered.");
    }
}
