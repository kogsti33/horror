package com.horrormod.entity;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;

public class EntityIllusionPlayer extends EntityCreature {

    private String mimickedPlayerName = "";
    private int ticksAlive   = 0;
    private int lifespanTicks;
    private boolean vanished = false;

    public EntityIllusionPlayer(World world) {
        super(world);
        this.isImmuneToFire = true;
        this.noClip = true;
        this.lifespanTicks = 600 + world.rand.nextInt(1200);
        this.setSize(0.6f, 1.8f);
    }

    public void setMimickedPlayer(String name) {
        this.mimickedPlayerName = name;
    }

    public String getMimickedPlayerName() {
        return mimickedPlayerName;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(1.0);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.0);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) return;

        ticksAlive++;

        EntityPlayer nearest = world.getClosestPlayerToEntity(this, 64);
        if (nearest == null) {
            if (ticksAlive > lifespanTicks) vanishWithEffects();
            return;
        }

        double dx = nearest.posX - posX;
        double dz = nearest.posZ - posZ;
        rotationYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));

        double distSq = getDistanceSq(nearest);

        // Whisper every 5 sec if close
        if (ticksAlive % 100 == 0 && distSq < 400) {
            world.playSound(null, posX, posY, posZ,
                SoundEvent.REGISTRY.getObject(new ResourceLocation("ambient.cave")),
                SoundCategory.HOSTILE, 0.15f,
                1.8f + world.rand.nextFloat() * 0.4f);
        }

        if (distSq < 64.0 || ticksAlive >= lifespanTicks) {
            vanishWithEffects();
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (!vanished) vanishWithEffects();
        return false;
    }

    private void vanishWithEffects() {
        if (vanished) return;
        vanished = true;
        for (int i = 0; i < 25; i++) {
            world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL,
                posX + (world.rand.nextDouble() - 0.5),
                posY + world.rand.nextDouble() * 2,
                posZ + (world.rand.nextDouble() - 0.5),
                0, 0.05, 0
            );
        }
        world.playSound(null, posX, posY, posZ,
            SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.endermen.stare")),
            SoundCategory.HOSTILE, 0.6f, 0.3f + world.rand.nextFloat() * 0.3f);
        setDead();
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        compound.setString("MimickedPlayer", mimickedPlayerName);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        mimickedPlayerName = compound.getString("MimickedPlayer");
    }

    @Override
    public boolean getAlwaysRenderNameTag() { return false; }
    @Override
    public String getName() { return ""; }
    @Override
    protected boolean canDespawn() { return false; }
    @Override
    public boolean canBePushed() { return false; }
    @Override
    protected SoundEvent getAmbientSound() { return null; }
    @Override
    protected SoundEvent getHurtSound(DamageSource src) { return null; }
    @Override
    protected SoundEvent getDeathSound() { return null; }
}
