package com.horrormod.entity;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class EntityTheWatcher extends EntityCreature {

    private int ticksAlive = 0;
    private int lifespanTicks;
    private boolean vanished = false;

    public EntityTheWatcher(World world) {
        super(world);
        this.isImmuneToFire = true;
        this.noClip = false;
        this.lifespanTicks = 200 + world.rand.nextInt(100);
        this.setSize(0.6f, 1.8f);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(1.0);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.0);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) return;

        ticksAlive++;

        EntityPlayer nearest = world.getClosestPlayerToEntity(this, 64);
        if (nearest != null) {
            double dx = nearest.posX - posX;
            double dz = nearest.posZ - posZ;
            rotationYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));

            if (getDistanceSq(nearest) < 25.0 && !vanished) {
                vanishWithEffects();
                return;
            }
        }

        if (ticksAlive >= lifespanTicks && !vanished) {
            vanishWithEffects();
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (!vanished) vanishWithEffects();
        return false;
    }

    private void vanishWithEffects() {
        vanished = true;
        for (int i = 0; i < 20; i++) {
            world.spawnParticle(EnumParticleTypes.SMOKE_LARGE,
                posX + (world.rand.nextDouble() - 0.5),
                posY + world.rand.nextDouble() * 2,
                posZ + (world.rand.nextDouble() - 0.5),
                0, 0.05, 0
            );
        }
        world.playSound(null, posX, posY, posZ,
            net.minecraft.util.SoundEvent.REGISTRY.getObject(
                new net.minecraft.util.ResourceLocation("entity.blaze.death")),
            net.minecraft.util.SoundCategory.HOSTILE, 0.5f,
            0.5f + world.rand.nextFloat() * 0.5f);
        setDead();
    }

    @Override
    protected boolean canDespawn() { return false; }
    @Override
    public boolean canBePushed() { return false; }
    @Override
    protected net.minecraft.util.SoundEvent getAmbientSound() { return null; }
    @Override
    protected net.minecraft.util.SoundEvent getHurtSound(DamageSource src) { return null; }
    @Override
    protected net.minecraft.util.SoundEvent getDeathSound() { return null; }
    @Override
    public boolean isNonBoss() { return true; }
    @Override
    public boolean getAlwaysRenderNameTag() { return false; }
}
