package com.horrormod.event;

import com.horrormod.HorrorMod;
import com.horrormod.config.HorrorConfig;
import com.horrormod.entity.*;
import com.horrormod.world.RealityTearEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.List;
import java.util.Random;

public class HorrorEventHandler {

    private final Random rand = new Random();
    private long globalTick = 0;

    private long nextSoundTick       = -1;
    private long nextChunkTearTick   = -1;
    private long nextIllusionTick    = -1;
    private long nextHerobrineDay    = -1;
    private long nextWatcherTick     = -1;
    private long nextFalseEffectTick = -1;
    private long nextFractureTick    = -1;

    private EntityHerobrine activeHerobrine = null;

    private static final String[] HORROR_SOUNDS = {
        "ambient.cave",
        "entity.endermen.stare",
        "entity.ghast.moan",
        "entity.ghast.scream",
        "entity.endermen.ambient",
        "entity.blaze.ambient",
    };

    private static final String[] TEAR_MESSAGES = {
        "Reality tears apart...",
        "Something was never really there.",
        "The fabric unravels.",
        "It crumbles into nothing.",
        "Do you feel that? Something is missing.",
        "̴̵̷̸̡̢̧̨̛...",
    };

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        globalTick++;

        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;

        List<EntityPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) return;

        if (nextSoundTick < 0) initTimers();

        // 1. Ambient sounds
        if (globalTick >= nextSoundTick) {
            for (EntityPlayer p : players) playAmbientSound(p);
            scheduleNextSound();
        }

        // 2. Chunk tear
        if (globalTick >= nextChunkTearTick) {
            for (EntityPlayer p : players)
                RealityTearEvent.tearChunkNear(p, rand);
            scheduleNextChunkTear();
        }

        // 3. Illusion (multiplayer only)
        if (globalTick >= nextIllusionTick && players.size() >= 2) {
            EntityPlayer target = players.get(rand.nextInt(players.size()));
            spawnIllusion(target, players);
            scheduleNextIllusion();
        }

        // 4. Herobrine
        World world = server.worlds[0];
        long worldDay = world.getTotalWorldTime() / 24000L;
        if (nextHerobrineDay < 0) {
            nextHerobrineDay = worldDay + HorrorConfig.herobrineMinDays
                + rand.nextInt(HorrorConfig.herobrineMaxDays - HorrorConfig.herobrineMinDays + 1);
        }
        if (worldDay >= nextHerobrineDay && (activeHerobrine == null || activeHerobrine.isDead)) {
            EntityPlayer target = players.get(rand.nextInt(players.size()));
            activeHerobrine = spawnHerobrine(target);
            nextHerobrineDay = worldDay + HorrorConfig.herobrineMinDays
                + rand.nextInt(HorrorConfig.herobrineMaxDays - HorrorConfig.herobrineMinDays + 1);
        }

        // 5. Watcher
        if (globalTick >= nextWatcherTick) {
            EntityPlayer target = players.get(rand.nextInt(players.size()));
            spawnWatcher(target);
            scheduleNextWatcher();
        }

        // 6. False effects
        if (globalTick >= nextFalseEffectTick) {
            EntityPlayer target = players.get(rand.nextInt(players.size()));
            applyFalseEffect(target);
            scheduleNextFalseEffect();
        }

        // 7. Fracture boss
        if (nextFractureTick < 0) scheduleFracture();
        if (globalTick >= nextFractureTick) {
            EntityPlayer target = players.get(rand.nextInt(players.size()));
            spawnFracture(target);
            scheduleFracture();
        }
    }

    // ── Timers ────────────────────────────────────────────────────────────

    private void initTimers() {
        scheduleNextSound();
        scheduleNextChunkTear();
        scheduleNextIllusion();
        scheduleNextWatcher();
        scheduleNextFalseEffect();
    }

    private void scheduleNextSound() {
        nextSoundTick = globalTick + (HorrorConfig.soundMinSec
            + rand.nextInt(HorrorConfig.soundMaxSec - HorrorConfig.soundMinSec + 1)) * 20L;
    }

    private void scheduleNextChunkTear() {
        nextChunkTearTick = globalTick + (HorrorConfig.chunkTearMinMin
            + rand.nextInt(HorrorConfig.chunkTearMaxMin - HorrorConfig.chunkTearMinMin + 1)) * 60L * 20L;
    }

    private void scheduleNextIllusion() {
        nextIllusionTick = globalTick + (HorrorConfig.illusionMinSec
            + rand.nextInt(HorrorConfig.illusionMaxSec - HorrorConfig.illusionMinSec + 1)) * 20L;
    }

    private void scheduleNextWatcher() {
        nextWatcherTick = globalTick + (HorrorConfig.watcherMinSec
            + rand.nextInt(HorrorConfig.watcherMaxSec - HorrorConfig.watcherMinSec + 1)) * 20L;
    }

    private void scheduleNextFalseEffect() {
        nextFalseEffectTick = globalTick + (HorrorConfig.falseEffectMinSec
            + rand.nextInt(HorrorConfig.falseEffectMaxSec - HorrorConfig.falseEffectMinSec + 1)) * 20L;
    }

    private void scheduleFracture() {
        nextFractureTick = globalTick + (long)(HorrorConfig.fractureMinDays
            + rand.nextInt(HorrorConfig.fractureMaxDays - HorrorConfig.fractureMinDays + 1)) * 24000L;
    }

    // ── Events ────────────────────────────────────────────────────────────

    private void playAmbientSound(EntityPlayer player) {
        String sound = HORROR_SOUNDS[rand.nextInt(HORROR_SOUNDS.length)];
        float vol   = 0.4f + rand.nextFloat() * 0.6f;
        float pitch = 0.6f + rand.nextFloat() * 0.8f;
        double ox = (rand.nextDouble() - 0.5) * 20;
        double oy = (rand.nextDouble() - 0.5) * 5;
        double oz = (rand.nextDouble() - 0.5) * 20;
        player.world.playSound(null,
            player.posX + ox, player.posY + oy, player.posZ + oz,
            net.minecraft.util.SoundEvent.REGISTRY.getObject(new net.minecraft.util.ResourceLocation(sound)),
            net.minecraft.util.SoundCategory.AMBIENT, vol, pitch);
    }

    private void spawnIllusion(EntityPlayer target, List<EntityPlayer> all) {
        EntityPlayer mimic = null;
        for (EntityPlayer p : all) {
            if (p != target) { mimic = p; break; }
        }
        if (mimic == null) return;

        double angle = rand.nextDouble() * Math.PI * 2;
        double dist  = 16 + rand.nextInt(17);
        double sx = target.posX + Math.sin(angle) * dist;
        double sz = target.posZ + Math.cos(angle) * dist;
        int sy = target.world.getHeight((int)sx, (int)sz);

        EntityIllusionPlayer illusion = new EntityIllusionPlayer(target.world);
        illusion.setMimickedPlayer(mimic.getName());
        illusion.setPosition(sx, sy, sz);
        target.world.spawnEntity(illusion);
    }

    private EntityHerobrine spawnHerobrine(EntityPlayer target) {
        double angle = rand.nextDouble() * Math.PI * 2;
        double dist  = 48 + rand.nextInt(17);
        double sx = target.posX + Math.sin(angle) * dist;
        double sz = target.posZ + Math.cos(angle) * dist;
        int sy = target.world.getHeight((int)sx, (int)sz);

        EntityHerobrine h = new EntityHerobrine(target.world);
        h.setTargetPlayer(target);
        h.setPosition(sx, sy, sz);
        target.world.spawnEntity(h);
        return h;
    }

    private void spawnWatcher(EntityPlayer target) {
        double angle = rand.nextDouble() * Math.PI * 2;
        double dist  = 18 + rand.nextInt(8);
        double sx = target.posX + Math.sin(angle) * dist;
        double sz = target.posZ + Math.cos(angle) * dist;
        int sy = target.world.getHeight((int)sx, (int)sz);

        EntityTheWatcher w = new EntityTheWatcher(target.world);
        w.setPosition(sx, sy, sz);
        target.world.spawnEntity(w);
    }

    private void applyFalseEffect(EntityPlayer player) {
        switch (rand.nextInt(3)) {
            case 0:
                // Flash health to near-zero
                float real = player.getHealth();
                player.setHealth(0.5f);
                player.playSound(
                    net.minecraft.util.SoundEvent.REGISTRY.getObject(
                        new net.minecraft.util.ResourceLocation("entity.player.hurt")),
                    1.0f, 1.0f);
                player.setHealth(real);
                player.sendMessage(new TextComponentString(
                    TextFormatting.DARK_RED + "Your heart stopped for a moment..."));
                break;
            case 1:
                player.getFoodStats().setFoodLevel(0);
                player.sendMessage(new TextComponentString(
                    TextFormatting.GRAY + "Something drained the life from you."));
                break;
            case 2:
                int from = rand.nextInt(36);
                int to   = rand.nextInt(36);
                if (from != to && player.inventory.getStackInSlot(from) != net.minecraft.item.ItemStack.EMPTY) {
                    net.minecraft.item.ItemStack a = player.inventory.getStackInSlot(from).copy();
                    net.minecraft.item.ItemStack b = player.inventory.getStackInSlot(to).copy();
                    player.inventory.setInventorySlotContents(to, a);
                    player.inventory.setInventorySlotContents(from, b);
                    player.sendMessage(new TextComponentString(
                        TextFormatting.DARK_GRAY + "Where did that go...?"));
                }
                break;
        }
    }

    private void spawnFracture(EntityPlayer target) {
        double angle = rand.nextDouble() * Math.PI * 2;
        double dist  = 20 + rand.nextInt(16);
        double sx = target.posX + Math.sin(angle) * dist;
        double sz = target.posZ + Math.cos(angle) * dist;
        int sy = target.world.getHeight((int)sx, (int)sz);

        EntityTheFracture f = new EntityTheFracture(target.world);
        f.setPosition(sx, sy, sz);
        target.world.spawnEntity(f);

        target.sendMessage(new TextComponentString(
            TextFormatting.DARK_RED + "" + TextFormatting.BOLD + "THE FRACTURE APPROACHES."));
    }
}
