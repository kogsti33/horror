package com.horrormod.config;

import net.minecraftforge.common.config.Configuration;

import java.io.File;

public class HorrorConfig {

    public static int soundMinSec    = 30;
    public static int soundMaxSec    = 300;

    public static int chunkTearMinMin = 15;
    public static int chunkTearMaxMin = 45;

    public static int illusionMinSec  = 600;
    public static int illusionMaxSec  = 1800;

    public static int herobrineMinDays = 1;
    public static int herobrineMaxDays = 3;

    public static int watcherMinSec   = 120;
    public static int watcherMaxSec   = 360;

    public static int falseEffectMinSec = 90;
    public static int falseEffectMaxSec = 240;

    public static int fractureMinDays = 2;
    public static int fractureMaxDays = 5;

    public static int settingsManipMinSec = 60;
    public static int settingsManipMaxSec = 180;

    public static void init(File file) {
        Configuration cfg = new Configuration(file);
        cfg.load();

        soundMinSec    = cfg.getInt("soundMin",    "sound",   30,  10, 600,  "Min sound interval (sec)");
        soundMaxSec    = cfg.getInt("soundMax",    "sound",   300, 30, 1800, "Max sound interval (sec)");

        chunkTearMinMin = cfg.getInt("tearMin",    "chunk",   15,  5,  120,  "Min chunk tear interval (min)");
        chunkTearMaxMin = cfg.getInt("tearMax",    "chunk",   45,  10, 240,  "Max chunk tear interval (min)");

        illusionMinSec  = cfg.getInt("illusionMin","illusion",600, 60, 3600, "Min illusion interval (sec)");
        illusionMaxSec  = cfg.getInt("illusionMax","illusion",1800,120,7200, "Max illusion interval (sec)");

        herobrineMinDays = cfg.getInt("herobrineMin","herobrine",1,1,10,"Min days between Herobrine");
        herobrineMaxDays = cfg.getInt("herobrineMax","herobrine",3,1,20,"Max days between Herobrine");

        watcherMinSec   = cfg.getInt("watcherMin", "watcher", 120, 30, 600,  "Min watcher interval (sec)");
        watcherMaxSec   = cfg.getInt("watcherMax", "watcher", 360, 60, 1800, "Max watcher interval (sec)");

        falseEffectMinSec = cfg.getInt("falseMin", "effects", 90,  30, 600,  "Min false effect interval (sec)");
        falseEffectMaxSec = cfg.getInt("falseMax", "effects", 240, 60, 1800, "Max false effect interval (sec)");

        fractureMinDays = cfg.getInt("fractureMin","fracture",2,1,10,"Min days between Fracture boss");
        fractureMaxDays = cfg.getInt("fractureMax","fracture",5,2,20,"Max days between Fracture boss");

        settingsManipMinSec = cfg.getInt("settingsMin","settings",60, 30,600, "Min settings manipulation interval (sec)");
        settingsManipMaxSec = cfg.getInt("settingsMax","settings",180,60,1800,"Max settings manipulation interval (sec)");

        if (cfg.hasChanged()) cfg.save();
    }
}
