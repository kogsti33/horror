package com.horrormod;

public class CommonProxy {
    public void registerRenderers() {}
}
