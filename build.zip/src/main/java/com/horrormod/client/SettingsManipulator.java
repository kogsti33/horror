package com.horrormod.client;

import com.horrormod.config.HorrorConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.Random;

@SideOnly(Side.CLIENT)
public class SettingsManipulator {

    private final Random rand = new Random();
    private final Minecraft mc = Minecraft.getMinecraft();

    private enum Phase { WAITING, ACTIVE, RESTORING }
    private Phase phase = Phase.WAITING;

    private long tick          = 0;
    private long nextEventTick = -1;
    private long effectEndTick = -1;

    private float savedGamma;
    private int   savedRenderDist;
    private float savedFOV;

    private float fovDir     = 1f;
    private float currentFOV = 70f;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (mc.player == null || mc.world == null) return;

        tick++;
        if (nextEventTick < 0) scheduleNext();

        switch (phase) {
            case WAITING:
                if (tick >= nextEventTick) {
                    saveSettings();
                    currentFOV = mc.gameSettings.fovSetting;
                    int dur = HorrorConfig.settingsManipMinSec
                        + rand.nextInt(HorrorConfig.settingsManipMaxSec - HorrorConfig.settingsManipMinSec + 1);
                    effectEndTick = tick + dur * 20L;
                    phase = Phase.ACTIVE;
                }
                break;
            case ACTIVE:
                applyEffects();
                if (tick >= effectEndTick) phase = Phase.RESTORING;
                break;
            case RESTORING:
                restoreSettings();
                scheduleNext();
                phase = Phase.WAITING;
                break;
        }
    }

    private void saveSettings() {
        savedGamma      = mc.gameSettings.gammaSetting;
        savedRenderDist = mc.gameSettings.renderDistanceChunks;
        savedFOV        = mc.gameSettings.fovSetting;
    }

    private void restoreSettings() {
        mc.gameSettings.gammaSetting         = savedGamma;
        mc.gameSettings.renderDistanceChunks = savedRenderDist;
        mc.gameSettings.fovSetting           = savedFOV;
        mc.renderGlobal.loadRenderers();
    }

    private void applyEffects() {
        // 1. Darkness
        mc.gameSettings.gammaSetting = 0f;

        // 2. Tiny render distance
        if (mc.gameSettings.renderDistanceChunks != 2) {
            mc.gameSettings.renderDistanceChunks = 2;
            mc.renderGlobal.loadRenderers();
        }

        // 3. FOV sweep 30–110
        currentFOV += fovDir * 0.4f;
        if (currentFOV > 110f) { currentFOV = 110f; fovDir = -1f; }
        if (currentFOV < 30f)  { currentFOV = 30f;  fovDir =  1f; }
        mc.gameSettings.fovSetting = currentFOV;
    }

    private void scheduleNext() {
        int range = HorrorConfig.settingsManipMaxSec - HorrorConfig.settingsManipMinSec;
        nextEventTick = tick + (HorrorConfig.settingsManipMinSec + rand.nextInt(range + 1)) * 20L;
    }
}
