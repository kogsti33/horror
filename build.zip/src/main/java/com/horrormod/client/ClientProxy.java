package com.horrormod.client;

import com.horrormod.CommonProxy;
import com.horrormod.entity.*;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class ClientProxy extends CommonProxy {

    @Override
    public void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(
            EntityTheWatcher.class,
            manager -> new RenderTheWatcher(manager)
        );
        RenderingRegistry.registerEntityRenderingHandler(
            EntityHerobrine.class,
            manager -> new RenderHerobrine(manager)
        );
        RenderingRegistry.registerEntityRenderingHandler(
            EntityIllusionPlayer.class,
            manager -> new RenderIllusionPlayer(manager)
        );
        RenderingRegistry.registerEntityRenderingHandler(
            EntityTheFracture.class,
            manager -> new RenderTheFracture(manager)
        );

        FMLCommonHandler.instance().bus().register(new SettingsManipulator());
    }
}
