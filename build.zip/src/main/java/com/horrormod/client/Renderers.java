package com.horrormod.client;

import com.horrormod.entity.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

// ── The Watcher ───────────────────────────────────────────────────────────────
class RenderTheWatcher extends RenderBiped<EntityTheWatcher> {

    private static final ResourceLocation TEX =
        new ResourceLocation("horrormod", "textures/entity/watcher.png");

    public RenderTheWatcher(RenderManager rm) {
        super(rm, new ModelBiped(), 0f);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityTheWatcher entity) { return TEX; }

    @Override
    public void doRender(EntityTheWatcher e, double x, double y, double z, float yaw, float pt) {
        if (e.world.rand.nextInt(10) == 0)
            GlStateManager.color(1f, 1f, 1f, 0.8f);
        super.doRender(e, x, y, z, yaw, pt);
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    @Override
    protected boolean canRenderName(EntityTheWatcher e) { return false; }
}

// ── Herobrine ─────────────────────────────────────────────────────────────────
class RenderHerobrine extends RenderBiped<EntityHerobrine> {

    private static final ResourceLocation TEX =
        new ResourceLocation("horrormod", "textures/entity/herobrine.png");

    public RenderHerobrine(RenderManager rm) {
        super(rm, new ModelBiped(), 0f);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityHerobrine entity) { return TEX; }

    @Override
    public void doRender(EntityHerobrine e, double x, double y, double z, float yaw, float pt) {
        GlStateManager.color(0.95f, 0.95f, 1.0f, 1.0f);
        super.doRender(e, x, y, z, yaw, pt);
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    @Override
    protected boolean canRenderName(EntityHerobrine e) { return false; }
}

// ── Illusion Player ───────────────────────────────────────────────────────────
class RenderIllusionPlayer extends RenderBiped<EntityIllusionPlayer> {

    private static final ResourceLocation STEVE =
        new ResourceLocation("textures/entity/steve.png");

    public RenderIllusionPlayer(RenderManager rm) {
        super(rm, new ModelBiped(), 0f);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityIllusionPlayer entity) {
        String name = entity.getMimickedPlayerName();
        if (name != null && !name.isEmpty()) {
            NetworkPlayerInfo info = Minecraft.getMinecraft().getConnection() == null
                ? null : Minecraft.getMinecraft().getConnection().getPlayerInfo(name);
            if (info != null) {
                ResourceLocation loc = info.getLocationSkin();
                if (loc != null) return loc;
            }
        }
        return STEVE;
    }

    @Override
    public void doRender(EntityIllusionPlayer e, double x, double y, double z, float yaw, float pt) {
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA,
                                  GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.color(1f, 1f, 1f, 0.7f);
        super.doRender(e, x, y, z, yaw, pt);
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.disableBlend();
    }

    @Override
    protected boolean canRenderName(EntityIllusionPlayer e) { return false; }
}

// ── The Fracture ──────────────────────────────────────────────────────────────
class RenderTheFracture extends RenderBiped<EntityTheFracture> {

    private static final ResourceLocation TEX =
        new ResourceLocation("horrormod", "textures/entity/fracture.png");

    public RenderTheFracture(RenderManager rm) {
        super(rm, new ModelBiped(), 0.5f);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityTheFracture entity) { return TEX; }

    @Override
    public void doRender(EntityTheFracture e, double x, double y, double z, float yaw, float pt) {
        GlStateManager.pushMatrix();
        float sx = 1.0f + (float)(Math.random() * 0.06 - 0.03);
        float sy = 1.0f + (float)(Math.random() * 0.10 - 0.05);
        GlStateManager.scale(sx, sy, sx);
        float pulse = 0.7f + 0.3f * (float)Math.abs(Math.sin(System.currentTimeMillis() * 0.003));
        GlStateManager.color(1.0f, pulse * 0.4f, pulse * 0.4f, 1.0f);
        super.doRender(e, x, y, z, yaw, pt);
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    @Override
    protected boolean canRenderName(EntityTheFracture e) { return false; }
}
