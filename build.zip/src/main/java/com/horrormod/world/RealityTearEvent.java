package com.horrormod.world;

import com.horrormod.HorrorMod;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RealityTearEvent {

    private static final Map<Long, Long> tornChunks = new HashMap<>();

    private static final String[] TEAR_MESSAGES = {
        TextFormatting.DARK_RED   + "Reality tears apart...",
        TextFormatting.DARK_GRAY  + "Something was never really there.",
        TextFormatting.GRAY       + "The fabric unravels.",
        TextFormatting.DARK_RED   + "It crumbles into nothing.",
        TextFormatting.DARK_PURPLE + "Do you feel that? Something is missing.",
    };

    public static void tearChunkNear(EntityPlayer player, Random rand) {
        World world = player.world;

        int chunkRadius  = 4; // 64 blocks / 16
        int playerChunkX = (int) Math.floor(player.posX / 16.0);
        int playerChunkZ = (int) Math.floor(player.posZ / 16.0);

        int offsetX = rand.nextInt(chunkRadius * 2 + 1) - chunkRadius;
        int offsetZ = rand.nextInt(chunkRadius * 2 + 1) - chunkRadius;

        int cx = playerChunkX + (offsetX == 0 && offsetZ == 0 ? 1 : offsetX);
        int cz = playerChunkZ + offsetZ;

        eraseChunk(world, cx, cz, rand);

        long key = chunkKey(cx, cz);
        tornChunks.put(key, world.getTotalWorldTime() / 24000L);

        String msg = TEAR_MESSAGES[rand.nextInt(TEAR_MESSAGES.length)];
        player.sendMessage(new TextComponentString(msg));

        double centerX = cx * 16 + 8;
        double centerZ = cz * 16 + 8;
        SoundEvent portal = SoundEvent.REGISTRY.getObject(new ResourceLocation("block.portal.travel"));
        SoundEvent explode = SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.generic.explode"));
        if (portal  != null) world.playSound(null, centerX, player.posY, centerZ, portal,  SoundCategory.BLOCKS, 3.0f, 0.3f);
        if (explode != null) world.playSound(null, centerX, player.posY, centerZ, explode, SoundCategory.BLOCKS, 2.0f, 0.3f);

        HorrorMod.LOG.info("[HorrorMod] Reality tear at chunk ({}, {})", cx, cz);
    }

    private static void eraseChunk(World world, int chunkX, int chunkZ, Random rand) {
        int baseX = chunkX * 16;
        int baseZ = chunkZ * 16;

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = 0; y < 256; y++) {
                    BlockPos pos = new BlockPos(baseX + x, y, baseZ + z);
                    if (!world.isAirBlock(pos) && world.getBlockState(pos).getBlock() != Blocks.BEDROCK) {
                        world.setBlockToAir(pos);
                        if (y % 4 == 0 && rand.nextInt(3) == 0) {
                            world.spawnParticle(EnumParticleTypes.SMOKE_LARGE,
                                baseX + x + 0.5, y + 0.5, baseZ + z + 0.5,
                                (rand.nextDouble() - 0.5) * 0.2, 0.05,
                                (rand.nextDouble() - 0.5) * 0.2
                            );
                        }
                    }
                }
            }
        }

        Chunk chunk = world.getChunkFromChunkCoords(chunkX, chunkZ);
        if (chunk != null) chunk.markDirty();
    }

    private static long chunkKey(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }
}
